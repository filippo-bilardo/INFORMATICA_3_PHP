<html>
<head>
    <title>Hello php</title>
</head>
<body>

    <h1>Hello World!</h1>
    <br />
    <?php
    phpinfo();
    ?> 

</body>
</html>

