<?php 
echo '<h1>Ciao ragazzi '; 
echo 'benvenuti nel mio corso PHP!</h1>';              
?>
